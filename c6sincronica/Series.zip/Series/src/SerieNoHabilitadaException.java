public class SerieNoHabilitadaException extends Exception{
    public SerieNoHabilitadaException(String messageForUser) {
        super(messageForUser);
    }

}
