public interface ISerie {

    String getSerie(String nombreSerie) throws SerieNoHabilitadaException;
}
