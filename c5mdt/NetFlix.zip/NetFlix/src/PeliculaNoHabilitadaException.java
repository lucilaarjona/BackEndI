public class PeliculaNoHabilitadaException extends Exception{
    public PeliculaNoHabilitadaException(String messageForUser) {
        super(messageForUser);
    }

}
