package factory;

import dto.Ropa;

import java.util.HashMap;
import java.util.Map;

public class RopaFactory {
    private static final Map<String, Ropa> ropaMap = new HashMap<>();
    private Integer contador = 0;


    public Ropa obtenerRopa(String talle, String tipo, boolean esNuevo, String importado){
        String claveRopa = "tipoRopa:"+tipo+" - talle:"+talle;

        if(!ropaMap.containsKey(claveRopa)){
            System.out.println("Creando ropa " + claveRopa);
            ropaMap.put(claveRopa, new Ropa(talle, tipo, esNuevo, importado));
            contador++;
        } else {
            System.out.println("La ropa ya esta creada " + claveRopa);

        }
        return ropaMap.get(claveRopa);

    }

    public String getContador() {
        return "La cantidad de pedidos es: " + contador;
    }
}
