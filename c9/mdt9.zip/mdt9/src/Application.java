import dto.Ropa;
import factory.RopaFactory;

public class Application {
    public static void main(String[] args) {
        RopaFactory ropaFactory = new RopaFactory();


            Ropa prenda1 = ropaFactory.obtenerRopa("M", "Remera", true, "nacional");
            Ropa prenda2 = ropaFactory.obtenerRopa("S", "Campera", false, "nacional");
            

        System.out.println(ropaFactory.getContador());

    }

}
